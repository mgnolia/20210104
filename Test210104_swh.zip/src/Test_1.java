
public class Test_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		       short num1 = 22;
		       short num2 = 11;
		       double result = num1+num2;
		       System.out.println(result);
		  }
		
		

	}


