
public class Test_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		short num1 = 3;
	       short num2 = 5;
	       System.out.println(num1+num2+ '=' +(num1+num2));

	}

}
